# Movie-recommendation-system

In this we have used Content and Collaborative filtering techniques of the Clustering Methods of Machine Learning in order to get ...

Similar Movies based on the Generes, Tags and Ratings mentioned in the .csv files located in the moverec/options/ directory 


Movie-recommendation-system/moverec/options
|---check.py
|---tage.py
|---gen.py
