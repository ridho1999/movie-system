from django.shortcuts import render

# Create your views here.
def sign(request):
    if request.method=='POST':
        



    else:
        return render(request,'signup.html')