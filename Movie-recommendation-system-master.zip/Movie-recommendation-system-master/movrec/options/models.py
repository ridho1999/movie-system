from django.db import models

# Create your models here.
class movie():
    movie_name:str
    tag:str
    rating :int